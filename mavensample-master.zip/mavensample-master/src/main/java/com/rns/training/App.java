package com.rns.training;

/**
 * Hello world Hello pirates!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World! Welcome to Digiinfotek" );
    }
}
